const cloudinary = require('cloudinary');
cloudinary.config({
  cloud_name: 'dnpnjmery',
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

exports.mediaUpload = (file, folder) => {
  return new Promise((resolve) => {
    cloudinary.uploader.upload(
      file,
      (result) => {
        resolve({ url: result.url, id: result.public_id, size: result.bytes });
      },
      { resource_type: 'auto', folder: folder }
    );
  });
};
