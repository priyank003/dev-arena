module.exports.authController = require('./auth.controller');
module.exports.userController = require('./user.controller');
module.exports.postController = require('./post.controller');
module.exports.jobController = require('./job.controller');
module.exports.converstaionController = require('./conversation.controller');
module.exports.subscriptionController = require('./subscription.controller');
